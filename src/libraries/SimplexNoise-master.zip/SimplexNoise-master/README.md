# SimplexNoise
Arduino Library for SimplexNoise

Video for servo example that currently uses a ESP8266: https://www.youtube.com/watch?v=SjVWmJZx0kk
